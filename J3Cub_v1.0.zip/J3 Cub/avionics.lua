size = { 2048, 2048 }

defineProperty("avionics", globalPropertyf("sim/cockpit2/switches/avionics_power_on"))

set(avionics, 0)

components = {

power {},   
--mixture {},

} 