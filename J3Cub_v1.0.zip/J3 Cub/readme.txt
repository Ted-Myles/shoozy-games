Piper J3 Cub for X-Plane 9 and X-Plane 10 modeled by rbugz95 v1.0
Pilot model by Berber (updated by XPFR) http://forums.x-plane.org/index.php?app=downloads&showfile=6187

Please do not reupload or modify without permission.

Important information:
Starter motor is engaged by clicking on the tachometer.
IFR pop-up panel is toggled by clicking on compass


Change log:

v1.0
-adjusted aircraft center of gravity
-adjusted engine angle (was set up for PA-11 not J3)
-fixed engine sound file name
-changed engine sound

v0.99
-adjusted wing data
-adjusted aircraft balance (no longer nose heavy)
-adjusted trim movement speed
-adjusted textures slightly
-corrected elevator movement
-added pilot figure (from pilot collection 1.1 by Berber updated by XPFR http://forums.x-plane.org/index.php?app=downloads&showfile=6187)
-tweaked 3D models slightly

v0.97
-adjusted wing data
-adjusted propeller data
-adjusted engine RPM green arc
-optimized texture palettes
-reduced texture size for some textures
-removed paint kit (made file size larger than needed)

v0.95
-Removed unused prop-disc plugin
-Added Fuel level Indicator
-Added IFR Pop-up Panel (Toggled on/off by clicking on Compass)
-Corrected Trim Handle movement direction
-Added big wheels version

v0.8
-Initial Release (Only released on FSE forums: www.fseconomy.net)

Known Issues:
-IFR panel doesn't pop-up on first click, pop-up displays after second click
-Fuel tank normal map is incorrect
