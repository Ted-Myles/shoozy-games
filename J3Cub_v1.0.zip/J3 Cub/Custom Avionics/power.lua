defineProperty("ignition", globalPropertyf("sim/cockpit2/engine/actuators/ignition_on[0]"))
defineProperty("battery", globalPropertyf("sim/cockpit2/electrical/battery_on"))
defineProperty("generator", globalPropertyf("sim/cockpit2/electrical/generator_on"))

function update()
	
	if get(ignition) > 0 then
		set(battery, 1)
		set(generator, 1)
	else
		set(battery, 0)
		set(generator, 0)
	end
	
end